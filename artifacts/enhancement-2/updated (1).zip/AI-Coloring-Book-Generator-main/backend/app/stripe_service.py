"""Stripe checkout and webhook handling."""

from __future__ import annotations

from datetime import datetime, timedelta

import stripe
from sqlalchemy.orm import Session

from backend.app.config import settings
from backend.app.credits import PLAN_CREDITS, PAYG_CREDITS_PER_DOLLAR, grant_credits
from backend.app.models import User

stripe.api_key = settings.stripe_secret_key

PLAN_PRICES = {
    "starter": settings.stripe_price_starter,
    "hobby": settings.stripe_price_hobby,
    "artist": settings.stripe_price_artist,
    "business": settings.stripe_price_business,
}


def _ensure_customer(db: Session, user: User) -> str:
    if user.stripe_customer_id:
        return user.stripe_customer_id
    customer = stripe.Customer.create(email=user.email, name=user.name or user.email)
    user.stripe_customer_id = customer.id
    db.commit()
    return customer.id


def create_subscription_checkout(db: Session, user: User, plan: str) -> str:
    price_id = PLAN_PRICES.get(plan)
    if not price_id:
        raise ValueError(f"Stripe price not configured for plan: {plan}")

    customer_id = _ensure_customer(db, user)
    session = stripe.checkout.Session.create(
        mode="subscription",
        customer=customer_id,
        line_items=[{"price": price_id, "quantity": 1}],
        success_url=f"{settings.frontend_url}/app/plans?success=1",
        cancel_url=f"{settings.frontend_url}/app/plans?canceled=1",
        metadata={"user_id": str(user.id), "plan": plan},
    )
    return session.url


def create_payg_checkout(db: Session, user: User, amount_usd: int) -> str:
    if amount_usd < 5:
        raise ValueError("Minimum top-up is $5")

    customer_id = _ensure_customer(db, user)
    session = stripe.checkout.Session.create(
        mode="payment",
        customer=customer_id,
        line_items=[
            {
                "price_data": {
                    "currency": "usd",
                    "product_data": {"name": f"{amount_usd * PAYG_CREDITS_PER_DOLLAR} Coloring Credits"},
                    "unit_amount": amount_usd * 100,
                },
                "quantity": 1,
            }
        ],
        success_url=f"{settings.frontend_url}/app/plans?success=1",
        cancel_url=f"{settings.frontend_url}/app/plans?canceled=1",
        metadata={
            "user_id": str(user.id),
            "type": "payg",
            "amount_usd": str(amount_usd),
        },
    )
    return session.url


def handle_checkout_completed(db: Session, session: dict) -> None:
    metadata = session.get("metadata", {})
    user_id = int(metadata.get("user_id", 0))
    user = db.get(User, user_id)
    if not user:
        return

    if metadata.get("type") == "payg":
        amount_usd = int(metadata.get("amount_usd", 0))
        credits = amount_usd * PAYG_CREDITS_PER_DOLLAR
        grant_credits(
            db,
            user,
            credits,
            source="payg",
            note=f"PAYG top-up: ${amount_usd}",
        )
        db.commit()
        return

    plan = metadata.get("plan")
    if plan and plan in PLAN_CREDITS:
        user.active_plan = plan
        grant_credits(
            db,
            user,
            PLAN_CREDITS[plan],
            source="subscription",
            plan_name=plan,
            note=f"Subscription activated: {plan.title()}",
            expires_at=datetime.utcnow() + timedelta(days=30),
        )
        db.commit()
