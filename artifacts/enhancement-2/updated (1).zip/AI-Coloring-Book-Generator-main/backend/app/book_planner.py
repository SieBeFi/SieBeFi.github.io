"""Plan varied coloring book pages from a single theme."""

from __future__ import annotations

import random

# Scene layouts that keep each page visually distinct
SCENE_VARIATIONS = [
    "full body portrait, centered composition",
    "playing in a sunny garden with flowers",
    "sitting under a big tree on a hill",
    "swimming or splashing at the beach",
    "flying or floating among stars and clouds",
    "having a picnic with a basket and blanket",
    "riding a bicycle on a country path",
    "surrounded by balloons and confetti",
    "in a magical forest with mushrooms",
    "wearing a party hat at a birthday scene",
    "building a sandcastle by the ocean",
    "reading a book on a cozy armchair",
    "dancing in the rain with puddles",
    "on a farm with a barn and fence",
    "exploring a castle with flags and towers",
]

# Art style twists applied across the book
STYLE_VARIATIONS = [
    "cute cartoon style",
    "simple toddler-friendly thick lines",
    "kawaii style with big eyes",
    "classic storybook illustration",
    "mandala-inspired decorative border",
    "minimal clean line art",
    "playful doodle style",
    "nature scene with leaves and vines",
    "geometric pattern accents in corners",
    "whimsical fairy-tale style",
]

THEME_SUBJECTS: dict[str, list[str]] = {
    "animals": [
        "a friendly lion", "a cute elephant", "a playful monkey", "a gentle giraffe",
        "a happy penguin", "a fluffy bunny", "a wise owl", "a smiling dolphin",
        "a cuddly bear", "a colorful parrot", "a sleepy cat", "a loyal dog",
    ],
    "dinosaurs": [
        "a T-Rex", "a Triceratops", "a Stegosaurus", "a Brachiosaurus",
        "a Pterodactyl", "a Velociraptor", "a Ankylosaurus", "a Diplodocus",
        "dinosaur eggs hatching", "a baby dinosaur", "dinosaurs in a volcano landscape",
    ],
    "ocean": [
        "a smiling whale", "a playful octopus", "a seahorse", "a sea turtle",
        "a starfish on the sand", "a clownfish in coral", "a jellyfish", "a crab on the beach",
        "a submarine underwater", "a mermaid", "a treasure chest on the ocean floor",
    ],
    "space": [
        "an astronaut on the moon", "a rocket ship blasting off", "a friendly alien",
        "planets and stars", "a space station", "a rover on Mars", "a comet in the sky",
        "an astronaut floating in space", "a UFO", "a satellite orbiting Earth",
    ],
    "fairy tale": [
        "a princess in a castle", "a brave knight", "a fire-breathing dragon",
        "a magical unicorn", "a fairy with wings", "a wizard with a wand",
        "a gingerbread house", "a magic carpet", "a enchanted forest",
    ],
}


def _match_theme_key(theme: str) -> str | None:
    lower = theme.lower()
    for key in THEME_SUBJECTS:
        if key in lower:
            return key
    return None


def plan_book_pages(
    theme: str,
    page_count: int,
    *,
    style: str | None = None,
    seed: int | None = None,
) -> list[dict[str, str]]:
    """Return page plans with unique subjects and style variations."""
    rng = random.Random(seed)
    page_count = max(1, min(page_count, 20))

    theme_key = _match_theme_key(theme)
    if theme_key:
        pool = list(THEME_SUBJECTS[theme_key])
        rng.shuffle(pool)
        subjects = []
        while len(subjects) < page_count:
            subjects.extend(pool)
        subjects = subjects[:page_count]
    else:
        scenes = rng.sample(SCENE_VARIATIONS, k=min(page_count, len(SCENE_VARIATIONS)))
        subjects = [f"{theme.strip()} - {scene}" for scene in scenes]
        while len(subjects) < page_count:
            extra = rng.choice(SCENE_VARIATIONS)
            subjects.append(f"{theme.strip()} - {extra}")
        subjects = subjects[:page_count]

    style_pool = list(STYLE_VARIATIONS)
    if style:
        style_pool = [style] + [s for s in style_pool if s != style]
    rng.shuffle(style_pool)

    pages: list[dict[str, str]] = []
    for i in range(page_count):
        subject = subjects[i]
        if theme_key:
            scene = rng.choice(SCENE_VARIATIONS)
            subject = f"{subject}, {scene}"
        page_style = style_pool[i % len(style_pool)]
        pages.append({"subject": subject, "style": page_style})

    return pages
