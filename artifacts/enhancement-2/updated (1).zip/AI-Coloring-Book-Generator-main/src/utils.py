"""Shared utilities."""

from __future__ import annotations

import re
from pathlib import Path


def slugify(text: str, max_length: int = 50) -> str:
    slug = re.sub(r"[^\w\s-]", "", text.lower())
    slug = re.sub(r"[\s_-]+", "-", slug).strip("-")
    return slug[:max_length] or "page"


def resolve_output_path(
    output_dir: Path, subject: str, filename: str | None = None
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    name = filename or f"{slugify(subject)}.png"
    if not name.endswith(".png"):
        name += ".png"
    return output_dir / name
