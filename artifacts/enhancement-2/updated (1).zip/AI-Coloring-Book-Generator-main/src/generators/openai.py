"""OpenAI DALL-E coloring book generator."""

from __future__ import annotations

import base64
from pathlib import Path

from openai import OpenAI

from src.config import Settings
from src.generators.base import ColoringBookGenerator
from src.prompts import build_prompt
from src.utils import resolve_output_path


class OpenAIGenerator(ColoringBookGenerator):
    def __init__(self, settings: Settings) -> None:
        super().__init__(settings)
        if not settings.openai_api_key:
            raise ValueError("OPENAI_API_KEY is required for the openai provider.")
        self.client = OpenAI(api_key=settings.openai_api_key)

    def generate_page(
        self,
        subject: str,
        *,
        style: str | None = None,
        filename: str | None = None,
        size: str = "1024x1024",
    ) -> Path:
        prompt = build_prompt(subject, style)
        response = self.client.images.generate(
            model=self.settings.openai_image_model,
            prompt=prompt,
            size=size,
            n=1,
            response_format="b64_json",
        )

        image_data = response.data[0].b64_json
        if not image_data:
            raise RuntimeError("OpenAI API returned no image data.")

        output_path = resolve_output_path(
            self.settings.output_dir, subject, filename
        )
        output_path.write_bytes(base64.b64decode(image_data))
        return output_path
