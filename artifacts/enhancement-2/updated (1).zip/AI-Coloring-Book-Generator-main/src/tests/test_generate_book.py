from pathlib import Path

from src.generators.base import ColoringBookGenerator


class MockGenerator(ColoringBookGenerator):
    """Test generator that simulates successful and failed page generation."""

    def generate_page(
        self,
        subject: str,
        *,
        style: str | None = None,
        filename: str | None = None,
        size: str = "1024x1024",
    ) -> Path:
        if subject == "fail":
            raise RuntimeError("Simulated generation failure")

        return Path(filename or f"{subject}.png")


def test_generate_book_continues_after_failure():
    """Verify that one failed page does not stop the remaining pages."""

    generator = MockGenerator(settings=None)

    subjects = ["cat", "fail", "dog"]

    successful_pages, failed_pages = generator.generate_book(subjects)

    assert successful_pages == [
        Path("01-cat.png"),
        Path("03-dog.png"),
    ]

    assert len(failed_pages) == 1
    assert failed_pages[0]["subject"] == "fail"
    assert failed_pages[0]["error"] == "Simulated generation failure"
