# ColoringBooks.AI

Full-stack AI coloring book generator with user accounts, **10 free pages on signup**, credit tracking, and Stripe billing — styled after your mockups.

## Features

- **Landing page** with hero, pricing, and free trial CTA
- **User registration & login** (JWT auth)
- **10 free credits** on signup (1 credit = 1 coloring page)
- **Dashboard** with credit stats and recent transactions
- **Image generation** via Gemini Nano Banana
- **Library** to browse and download past pages
- **Plans & Credits** — subscription tiers + pay-as-you-go top-ups via Stripe
- **Blocks generation** when credits run out (redirects to purchase)

## Quick start

### 1. Install dependencies

```bash
pip install -r requirements.txt
cd frontend && npm install && cd ..
```

### 2. Configure environment

```bash
cp .env.example .env
```

Required in `.env`:
- `GEMINI_API_KEY` — from [aistudio.google.com/apikey](https://aistudio.google.com/apikey)
- `SECRET_KEY` — random string for JWT tokens
- `STRIPE_SECRET_KEY` + price IDs — for payments (optional for local dev)

### 3. Run the app

**Terminal 1 — API:**
```bash
python3 run_api.py
```

**Terminal 2 — Frontend:**
```bash
cd frontend && npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## User flow

1. User clicks **"Try 10 Pages Free Trial"** → registers
2. Gets **10 PAYG credits** automatically
3. Generates coloring pages from **Image Generate** (1 credit each)
4. After 10 images → prompted to **Plans & Credits** to subscribe or top up
5. Stripe checkout adds subscription or PAYG credits

## Subscription plans

| Plan | Credits/month | Price |
|------|---------------|-------|
| Starter | 150 | $6.57/mo |
| Hobby | 500 | $13.32/mo |
| Artist | 1250 | $28.89/mo |
| Business | 3000 | $69.99/mo |

Pay-as-you-go: **$1 = 2 credits** (minimum $5 top-up)

## Project structure

```
├── backend/app/          # FastAPI API
│   ├── routers/          # auth, generate, billing, library
│   ├── credits.py        # 10 free credits + consumption logic
│   └── stripe_service.py # Stripe checkout & webhooks
├── frontend/src/         # React + Tailwind UI
│   ├── pages/            # Landing, Dashboard, Generate, Plans...
│   └── components/       # Sidebar layout, auth images
├── src/                  # Shared Python image generation (CLI)
├── run_api.py            # Start API server
└── main.py               # CLI (still works standalone)
```

## Stripe setup

1. Create products/prices in [Stripe Dashboard](https://dashboard.stripe.com/products)
2. Add price IDs to `.env`:
   ```
   STRIPE_PRICE_STARTER=price_...
   STRIPE_PRICE_HOBBY=price_...
   STRIPE_PRICE_ARTIST=price_...
   STRIPE_PRICE_BUSINESS=price_...
   ```
3. For webhooks (production), point to `POST /api/billing/webhook`

## CLI (optional)

The original command-line tool still works:

```bash
python3 main.py generate "a dinosaur" --provider gemini
```

## License

MIT
