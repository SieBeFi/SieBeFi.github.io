@echo off
cd /d "%~dp0\frontend"

if not exist node_modules (
    echo Frontend packages not installed yet. Installing now...
    echo This only needs to happen once.
    echo.
    call npm install
    if errorlevel 1 (
        echo.
        echo ERROR: Failed to install frontend packages.
        echo Try running: cd frontend ^&^& npm install
        pause
        exit /b 1
    )
    echo.
)

echo Starting Coloring Books frontend on http://localhost:5173
echo Keep this window open.
echo.
call npm run dev
pause
