import { useEffect, useState } from 'react';
import { api, type Transaction } from '../api';
import { useUser } from '../hooks/useUser';

export function TransactionsPage() {
  const { user } = useUser();
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    api.transactions().then(setTransactions).catch(() => setTransactions([]));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold">Transactions</h1>
      <p className="text-gray-500">Credit history for {user?.email}</p>

      <div className="card mt-8 overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-500">
            <tr>
              <th className="px-6 py-3">Date</th>
              <th className="px-6 py-3">Action</th>
              <th className="px-6 py-3">Amount</th>
              <th className="px-6 py-3">Note</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((tx) => (
              <tr key={tx.id} className="border-t border-gray-50">
                <td className="px-6 py-3 text-gray-400">{new Date(tx.created_at).toLocaleString()}</td>
                <td className="px-6 py-3 capitalize">{tx.action}</td>
                <td className={`px-6 py-3 font-semibold ${tx.amount >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                  {tx.amount >= 0 ? '+' : ''}{tx.amount}
                </td>
                <td className="px-6 py-3 text-gray-500">{tx.note}</td>
              </tr>
            ))}
            {!transactions.length && (
              <tr><td colSpan={4} className="px-6 py-8 text-center text-gray-400">No transactions yet</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
