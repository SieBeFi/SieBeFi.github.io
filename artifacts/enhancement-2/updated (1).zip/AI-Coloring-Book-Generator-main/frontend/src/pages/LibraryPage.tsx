import { useEffect, useState } from 'react';
import { api, type GeneratedImage } from '../api';
import { AuthImage, downloadAuthImage } from '../components/AuthImage';

export function LibraryPage() {
  const [images, setImages] = useState<GeneratedImage[]>([]);

  useEffect(() => {
    api.library().then(setImages).catch(() => setImages([]));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold">Library</h1>
      <p className="text-gray-500">All your generated coloring pages</p>

      {images.length === 0 ? (
        <div className="card mt-8 p-12 text-center text-gray-400">
          No images yet. Generate your first coloring page!
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {images.map((img) => (
            <div key={img.id} className="card overflow-hidden">
              <AuthImage src={img.image_url} alt={img.subject} className="aspect-square w-full object-cover" />
              <div className="p-4">
                <h3 className="font-semibold">{img.subject}</h3>
                <p className="text-xs text-[var(--pink)]">
                  {img.provider === 'openai' ? 'OpenAI DALL-E' : 'Gemini'}
                </p>
                {img.style && <p className="text-sm text-gray-500">{img.style}</p>}
                <button
                  type="button"
                  className="mt-2 text-sm font-medium text-[var(--pink)]"
                  onClick={() => downloadAuthImage(img.image_url, `${img.subject}.png`)}
                >
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
