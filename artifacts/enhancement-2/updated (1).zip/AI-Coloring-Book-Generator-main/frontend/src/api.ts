const TOKEN_KEY = 'cb_token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(path, { ...options, headers });
  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Request failed' }));
    throw new Error(error.detail || 'Request failed');
  }
  return response.json();
}

async function downloadFile(path: string, filename: string) {
  const token = getToken();
  const response = await fetch(path, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!response.ok) throw new Error('Download failed');
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export const api = {
  register: (email: string, password: string, name = '') =>
    request<{ access_token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    }),
  login: (email: string, password: string) =>
    request<{ access_token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  me: () => request<User>('/api/auth/me'),
  dashboard: () => request<DashboardStats>('/api/dashboard'),
  providers: () => request<ProvidersInfo>('/api/generate/providers'),
  generate: (subject: string, style?: string, provider?: string) =>
    request<GeneratedImage>('/api/generate', {
      method: 'POST',
      body: JSON.stringify({ subject, style, provider }),
    }),
  generateBook: async (
    payload: { theme: string; page_count: number; style?: string; provider?: string; title?: string },
    onEvent?: (event: BookStreamEvent) => void,
  ): Promise<ColoringBook> => {
    const token = getToken();
    const response = await fetch('/api/books/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Book generation failed' }));
      throw new Error(error.detail || 'Book generation failed');
    }

    const reader = response.body?.getReader();
    if (!reader) throw new Error('No response stream');

    const decoder = new TextDecoder();
    let buffer = '';
    let completedBook: ColoringBook | null = null;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const event = JSON.parse(line.slice(6)) as BookStreamEvent;
        onEvent?.(event);
        if (event.type === 'complete') completedBook = event.book;
        if (event.type === 'error') throw new Error(event.message);
      }
    }

    if (!completedBook) throw new Error('Book generation did not complete');
    return completedBook;
  },
  downloadBook: async (bookId: number, filename: string) => {
    await downloadFile(`/api/books/${bookId}/download`, filename);
  },
  downloadBookPdf: async (bookId: number, filename: string) => {
    await downloadFile(`/api/books/${bookId}/download/pdf`, filename);
  },
  books: () => request<BookListItem[]>('/api/books'),
  library: () => request<GeneratedImage[]>('/api/library'),
  transactions: () => request<Transaction[]>('/api/transactions'),
  creditLots: () => request<CreditLot[]>('/api/credits/lots'),
  checkout: (payload: { plan?: string; amount_usd?: number }) =>
    request<{ checkout_url: string }>('/api/billing/checkout', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};

export interface User {
  id: number;
  email: string;
  name: string;
  active_plan: string | null;
  total_credits: number;
  plan_credits: number;
  payg_credits: number;
  created_at: string;
}

export interface DashboardStats {
  total_credits: number;
  plan_credits: number;
  payg_credits: number;
  active_plan: string | null;
  images_generated: number;
  recent_transactions: Transaction[];
}

export interface Transaction {
  id: number;
  action: string;
  amount: number;
  note: string;
  created_at: string;
}

export interface CreditLot {
  id: number;
  source: string;
  plan_name: string | null;
  total_credits: number;
  remaining_credits: number;
  granted_at: string;
  expires_at: string | null;
}

export interface GeneratedImage {
  id: number;
  subject: string;
  style: string | null;
  provider: string;
  image_url: string;
  page_number: number | null;
  created_at: string;
}

export interface ColoringBook {
  id: number;
  title: string;
  theme: string;
  style: string | null;
  provider: string;
  page_count: number;
  pages: GeneratedImage[];
  created_at: string;
}

export interface BookListItem {
  id: number;
  title: string;
  theme: string;
  page_count: number;
  created_at: string;
}

export type BookStreamEvent =
  | { type: 'start'; total: number; title: string }
  | { type: 'progress'; current: number; total: number; subject: string }
  | { type: 'page'; page: GeneratedImage }
  | { type: 'complete'; book: ColoringBook }
  | { type: 'error'; message: string };

export interface ProvidersInfo {
  providers: string[];
  default: string;
}
