@echo off
echo ============================================
echo  Coloring Books - Windows Setup
echo ============================================
echo.

cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found.
    echo Install from https://www.python.org/downloads/
    echo Check "Add Python to PATH" during install.
    pause
    exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js/npm not found.
    echo Install from https://nodejs.org/
    pause
    exit /b 1
)

echo Installing Python packages...
python -m pip install -r requirements.txt
if errorlevel 1 pause & exit /b 1

echo.
echo Installing frontend packages...
cd frontend
call npm install
if errorlevel 1 pause & exit /b 1
cd ..

if not exist .env (
    echo.
    echo Creating .env from template...
    copy .env.example .env
    echo.
    echo IMPORTANT: Edit .env and add your API keys
)

echo.
echo ============================================
echo  Setup complete!
echo.
echo  Next steps:
echo    1. Edit .env and add your API keys
echo    2. Double-click start-api.bat      (keep window open)
echo    3. Double-click start-frontend.bat (keep window open)
echo    4. Open http://localhost:5173
echo ============================================
pause
