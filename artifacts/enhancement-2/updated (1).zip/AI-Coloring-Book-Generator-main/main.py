#!/usr/bin/env python3
"""Entry point for the AI Coloring Book Generator."""

from src.cli import cli

if __name__ == "__main__":
    cli()
