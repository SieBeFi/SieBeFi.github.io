"""Image generation routes."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.app.auth import get_current_user
from backend.app.config import settings
from backend.app.credits import consume_credit
from backend.app.database import get_db
from backend.app.image_service import generate_coloring_page_bytes, save_user_image
from backend.app.models import GeneratedImage, User
from backend.app.schemas import GenerateRequest, GeneratedImageResponse, ProvidersResponse

router = APIRouter(prefix="/generate", tags=["generate"])


@router.get("/providers", response_model=ProvidersResponse)
def list_providers():
    providers = settings.available_providers()
    if not providers:
        raise HTTPException(
            status_code=503,
            detail="No image API keys configured. Add GEMINI_API_KEY or OPENAI_API_KEY to .env",
        )
    return ProvidersResponse(providers=providers, default=settings.default_provider())


@router.post("", response_model=GeneratedImageResponse)
def generate_image(
    payload: GenerateRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    providers = settings.available_providers()
    if not providers:
        raise HTTPException(status_code=503, detail="No image API keys configured.")

    selected = (payload.provider or settings.default_provider()).lower()
    if selected not in providers:
        raise HTTPException(
            status_code=400,
            detail=f"Provider '{selected}' is not available. Configured: {', '.join(providers)}",
        )

    consume_credit(
        db,
        user,
        note=f"Generated ({selected}): {payload.subject[:60]}",
    )

    try:
        image_bytes, provider_used = generate_coloring_page_bytes(
            payload.subject, payload.style, provider=selected
        )
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    file_path = save_user_image(user.id, image_bytes)
    record = GeneratedImage(
        user_id=user.id,
        subject=payload.subject,
        style=payload.style,
        provider=provider_used,
        file_path=str(file_path),
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    return GeneratedImageResponse(
        id=record.id,
        subject=record.subject,
        style=record.style,
        provider=record.provider,
        image_url=f"/api/images/{record.id}",
        page_number=record.page_number,
        created_at=record.created_at,
    )
