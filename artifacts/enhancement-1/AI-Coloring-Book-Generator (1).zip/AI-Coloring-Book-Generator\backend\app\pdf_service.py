"""Build printable PDF coloring books from generated pages."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

from PIL import Image

# US Letter at 150 DPI — good balance of print quality and file size
PAGE_SIZE = (1275, 1650)
MARGIN = 50


def _fit_on_page(image: Image.Image) -> Image.Image:
    rgb = image.convert("RGB")
    canvas = Image.new("RGB", PAGE_SIZE, "white")
    max_w = PAGE_SIZE[0] - MARGIN * 2
    max_h = PAGE_SIZE[1] - MARGIN * 2
    fitted = rgb.copy()
    fitted.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
    x = (PAGE_SIZE[0] - fitted.width) // 2
    y = (PAGE_SIZE[1] - fitted.height) // 2
    canvas.paste(fitted, (x, y))
    return canvas


def build_book_pdf(image_paths: list[Path]) -> BytesIO:
    """Combine coloring page PNGs into a multi-page letter-size PDF."""
    pages: list[Image.Image] = []
    for path in image_paths:
        if not path.exists():
            continue
        with Image.open(path) as img:
            pages.append(_fit_on_page(img))

    if not pages:
        raise ValueError("No images found for this coloring book.")

    buffer = BytesIO()
    first, *rest = pages
    first.save(buffer, format="PDF", save_all=True, append_images=rest, resolution=150.0)
    buffer.seek(0)

    for page in pages:
        page.close()

    return buffer
