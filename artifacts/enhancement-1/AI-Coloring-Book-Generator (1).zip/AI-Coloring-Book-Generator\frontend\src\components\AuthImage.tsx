import { useEffect, useState } from 'react';
import { getToken } from '../api';

export function AuthImage({ src, alt, className }: { src: string; alt: string; className?: string }) {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const token = getToken();

    fetch(src, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => res.blob())
      .then((blob) => {
        if (active) setBlobUrl(URL.createObjectURL(blob));
      })
      .catch(() => active && setBlobUrl(null));

    return () => {
      active = false;
      if (blobUrl) URL.revokeObjectURL(blobUrl);
    };
  }, [src]);

  if (!blobUrl) {
    return <div className={`animate-pulse bg-gray-100 ${className ?? ''}`} />;
  }

  return <img src={blobUrl} alt={alt} className={className} />;
}

export async function downloadAuthImage(src: string, filename: string) {
  const token = getToken();
  const response = await fetch(src, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}
