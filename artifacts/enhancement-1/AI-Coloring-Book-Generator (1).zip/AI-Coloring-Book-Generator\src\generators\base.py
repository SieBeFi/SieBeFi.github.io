"""Base interface for coloring book generators."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from src.config import Settings


class ColoringBookGenerator(ABC):
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    @abstractmethod
    def generate_page(
        self,
        subject: str,
        *,
        style: str | None = None,
        filename: str | None = None,
        size: str = "1024x1024",
    ) -> Path:
        """Generate one coloring book page and save it as a PNG."""

    def generate_book(
        self,
        subjects: list[str],
        *,
        style: str | None = None,
        size: str = "1024x1024",
    ) -> list[Path]:
        """Generate multiple coloring book pages from a list of subjects."""
        from src.utils import slugify

        paths: list[Path] = []
        for index, subject in enumerate(subjects, start=1):
            filename = f"{index:02d}-{slugify(subject)}.png"
            path = self.generate_page(
                subject, style=style, filename=filename, size=size
            )
            paths.append(path)
        return paths
