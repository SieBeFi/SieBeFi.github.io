"""Command-line interface for the coloring book generator."""

from __future__ import annotations

import sys

import click

from src.config import SUPPORTED_PROVIDERS, Settings
from src.generators import create_generator


def _provider_option():
    return click.option(
        "--provider",
        "-p",
        type=click.Choice(SUPPORTED_PROVIDERS),
        default=None,
        help="Image API provider (default: openai, or IMAGE_PROVIDER env var).",
    )


@click.group()
@click.version_option(package_name="ai-coloring-book-generator")
def cli() -> None:
    """Generate AI coloring book pages with OpenAI DALL-E or Gemini Nano Banana."""


@cli.command("generate")
@click.argument("subject")
@_provider_option()
@click.option(
    "--style",
    "-s",
    default=None,
    help="Optional art style (e.g. 'cute cartoon', 'mandala').",
)
@click.option(
    "--output",
    "-o",
    default=None,
    help="Output filename (default: slug from subject).",
)
@click.option(
    "--size",
    default="1024x1024",
    type=click.Choice(["1024x1024", "1792x1024", "1024x1792"]),
    help="Image size (OpenAI DALL-E 3 only).",
)
def generate(
    subject: str,
    provider: str | None,
    style: str | None,
    output: str | None,
    size: str,
) -> None:
    """Generate a single coloring book page."""
    try:
        settings = Settings.from_env(provider=provider)
        generator = create_generator(settings)
        path = generator.generate_page(
            subject, style=style, filename=output, size=size
        )
        click.echo(f"Saved: {path}")
    except ValueError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Generation failed: {exc}", err=True)
        sys.exit(1)


@cli.command("book")
@click.argument("subjects", nargs=-1, required=True)
@_provider_option()
@click.option("--style", "-s", default=None, help="Shared art style for all pages.")
@click.option(
    "--file",
    "-f",
    "subjects_file",
    type=click.Path(exists=True, readable=True),
    help="Text file with one subject per line.",
)
@click.option(
    "--size",
    default="1024x1024",
    type=click.Choice(["1024x1024", "1792x1024", "1024x1792"]),
    help="Image size (OpenAI DALL-E 3 only).",
)
def book(
    subjects: tuple[str, ...],
    provider: str | None,
    style: str | None,
    subjects_file: str | None,
    size: str,
) -> None:
    """Generate a multi-page coloring book from subjects."""
    all_subjects = list(subjects)
    if subjects_file:
        with open(subjects_file, encoding="utf-8") as handle:
            all_subjects.extend(
                line.strip()
                for line in handle
                if line.strip() and not line.startswith("#")
            )

    if not all_subjects:
        click.echo("No subjects provided.", err=True)
        sys.exit(1)

    try:
        settings = Settings.from_env(provider=provider)
        generator = create_generator(settings)
        paths = generator.generate_book(all_subjects, style=style, size=size)
        click.echo(f"Generated {len(paths)} page(s) in {settings.output_dir}:")
        for path in paths:
            click.echo(f"  {path}")
    except ValueError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Generation failed: {exc}", err=True)
        sys.exit(1)


@cli.command("check")
@_provider_option()
def check(provider: str | None) -> None:
    """Verify that API keys are configured."""
    try:
        settings = Settings.from_env(provider=provider)
        click.echo("Configuration OK.")
        click.echo(f"  Provider: {settings.provider}")
        key_name = (
            "OPENAI_API_KEY"
            if settings.provider == "openai"
            else "GEMINI_API_KEY / GOOGLE_API_KEY"
        )
        click.echo(f"  {key_name}: {settings.masked_key()}")
        click.echo(f"  Model: {settings.active_model()}")
        click.echo(f"  Output dir: {settings.output_dir}")
    except ValueError as exc:
        click.echo(f"Configuration error: {exc}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    cli()
