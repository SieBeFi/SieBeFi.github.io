"""Image generation service for the web API."""

from __future__ import annotations

import base64
import uuid
from pathlib import Path

from google import genai
from openai import OpenAI

from backend.app.config import SUPPORTED_PROVIDERS, settings
from src.prompts import build_prompt


def _generate_with_gemini(subject: str, style: str | None) -> bytes:
    api_key = settings.resolved_gemini_key
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured on the server.")

    client = genai.Client(api_key=api_key)
    prompt = build_prompt(subject, style)
    response = client.models.generate_content(
        model=settings.gemini_image_model,
        contents=prompt,
    )

    candidates = getattr(response, "candidates", None) or []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        if not content:
            continue
        for part in getattr(content, "parts", None) or []:
            inline_data = getattr(part, "inline_data", None)
            if inline_data and inline_data.data:
                return inline_data.data

    raise RuntimeError("Gemini API returned no image data.")


def _generate_with_openai(subject: str, style: str | None) -> bytes:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured on the server.")

    client = OpenAI(api_key=settings.openai_api_key)
    prompt = build_prompt(subject, style)
    response = client.images.generate(
        model=settings.openai_image_model,
        prompt=prompt,
        size="1024x1024",
        n=1,
        response_format="b64_json",
    )

    image_data = response.data[0].b64_json
    if not image_data:
        raise RuntimeError("OpenAI API returned no image data.")
    return base64.b64decode(image_data)


def generate_coloring_page_bytes(
    subject: str,
    style: str | None = None,
    provider: str | None = None,
) -> tuple[bytes, str]:
    selected = (provider or settings.default_provider()).strip().lower()
    if selected not in SUPPORTED_PROVIDERS:
        raise ValueError(f"Unknown provider '{selected}'. Use: gemini or openai.")

    if selected == "openai":
        return _generate_with_openai(subject, style), "openai"
    return _generate_with_gemini(subject, style), "gemini"


def save_user_image(user_id: int, image_bytes: bytes) -> Path:
    user_dir = settings.uploads_dir / str(user_id)
    user_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{uuid.uuid4().hex}.png"
    path = user_dir / filename
    path.write_bytes(image_bytes)
    return path
