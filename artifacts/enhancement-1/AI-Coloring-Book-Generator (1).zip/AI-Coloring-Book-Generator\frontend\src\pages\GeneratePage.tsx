import { type FormEvent, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, type ColoringBook, type GeneratedImage } from '../api';
import { AuthImage, downloadAuthImage } from '../components/AuthImage';
import { useUser } from '../hooks/useUser';

const PAGE_OPTIONS = [5, 10, 15, 20];

const THEME_SUGGESTIONS = [
  'Dinosaurs',
  'Ocean animals',
  'Space adventure',
  'Fairy tale',
  'Farm animals',
  'Jungle safari',
];

export function GeneratePage() {
  const { user, refresh } = useUser();
  const [theme, setTheme] = useState('Dinosaurs');
  const [style, setStyle] = useState('');
  const [pageCount, setPageCount] = useState(10);
  const [provider, setProvider] = useState('gemini');
  const [providers, setProviders] = useState<string[]>(['gemini', 'openai']);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0, subject: '' });
  const [error, setError] = useState('');
  const [book, setBook] = useState<ColoringBook | null>(null);
  const [pages, setPages] = useState<GeneratedImage[]>([]);

  useEffect(() => {
    api.providers()
      .then((info) => {
        setProviders(info.providers);
        setProvider(info.default);
      })
      .catch(() => {});
  }, []);

  const credits = user?.total_credits ?? 0;
  const notEnoughCredits = credits < pageCount;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    setBook(null);
    setPages([]);
    setProgress({ current: 0, total: pageCount, subject: '' });

    try {
      const result = await api.generateBook(
        {
          theme,
          page_count: pageCount,
          style: style || undefined,
          provider,
        },
        (event) => {
          if (event.type === 'start') {
            setProgress({ current: 0, total: event.total, subject: 'Starting...' });
          }
          if (event.type === 'progress') {
            setProgress({
              current: event.current,
              total: event.total,
              subject: event.subject,
            });
          }
          if (event.type === 'page' && event.page) {
            setPages((prev) => [...prev, event.page!]);
          }
        },
      );
      setBook(result);
      await refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Book generation failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="text-2xl font-bold">Create Coloring Book</h1>
      <p className="text-gray-500">
        Generate a full coloring book at once — {pageCount} unique pages with varied designs.{' '}
        <span className="font-medium text-[var(--pink)]">{pageCount} credits</span> per book.
      </p>

      <div className="mt-4 rounded-xl bg-pink-50 px-4 py-3 text-sm">
        <span className="font-semibold text-[var(--pink)]">{credits} credits remaining</span>
        <span className="text-gray-500"> · Enough for {Math.floor(credits / pageCount) || 0} book(s) at {pageCount} pages</span>
      </div>

      {notEnoughCredits && (
        <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          You need {pageCount} credits for this book but only have {credits}.{' '}
          <Link to="/app/plans" className="font-semibold text-[var(--pink)] underline">
            Purchase a plan or top up credits
          </Link>
        </div>
      )}

      <form onSubmit={handleSubmit} className="card mt-6 space-y-4 p-6">
        <div>
          <label className="mb-1 block text-sm font-medium">Book Theme</label>
          <input
            className="input"
            placeholder="e.g. Dinosaurs, Ocean animals, Fairy tale"
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
            required
            disabled={loading || notEnoughCredits}
          />
          <div className="mt-2 flex flex-wrap gap-2">
            {THEME_SUGGESTIONS.map((suggestion) => (
              <button
                key={suggestion}
                type="button"
                className="rounded-full border border-gray-200 px-3 py-1 text-xs hover:bg-pink-50"
                onClick={() => setTheme(suggestion)}
                disabled={loading || notEnoughCredits}
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-sm font-medium">Number of Pages</label>
            <select
              className="input"
              value={pageCount}
              onChange={(e) => setPageCount(Number(e.target.value))}
              disabled={loading || notEnoughCredits}
            >
              {PAGE_OPTIONS.map((count) => (
                <option key={count} value={count}>
                  {count} pages ({count} credits)
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">Overall Style (optional)</label>
            <input
              className="input"
              placeholder="e.g. cute cartoon for kids ages 4-8"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              disabled={loading || notEnoughCredits}
            />
          </div>
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium">AI Provider</label>
          <div className="grid grid-cols-2 gap-3">
            {providers.includes('gemini') && (
              <button
                type="button"
                className={`rounded-xl border p-4 text-left transition ${
                  provider === 'gemini'
                    ? 'border-[var(--pink)] bg-pink-50 ring-2 ring-pink-100'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => setProvider('gemini')}
                disabled={loading || notEnoughCredits}
              >
                <p className="font-semibold">Gemini Nano Banana</p>
                <p className="text-xs text-gray-500">Google image generation</p>
              </button>
            )}
            {providers.includes('openai') && (
              <button
                type="button"
                className={`rounded-xl border p-4 text-left transition ${
                  provider === 'openai'
                    ? 'border-[var(--pink)] bg-pink-50 ring-2 ring-pink-100'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => setProvider('openai')}
                disabled={loading || notEnoughCredits}
              >
                <p className="font-semibold">OpenAI DALL-E</p>
                <p className="text-xs text-gray-500">DALL-E 3 line art</p>
              </button>
            )}
          </div>
        </div>

        {loading && (
          <div className="rounded-xl bg-gray-50 p-4">
            <p className="text-sm font-semibold text-[var(--pink)]">
              Generating page {progress.current} of {progress.total}...
            </p>
            <p className="mt-1 text-xs text-gray-500">{progress.subject}</p>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-gray-200">
              <div
                className="h-full bg-[var(--pink)] transition-all duration-500"
                style={{
                  width: `${progress.total ? (progress.current / progress.total) * 100 : 0}%`,
                }}
              />
            </div>
          </div>
        )}

        {error && <p className="rounded-xl bg-red-50 p-3 text-sm text-red-600">{error}</p>}

        <button
          className="btn-primary w-full disabled:opacity-50"
          type="submit"
          disabled={loading || notEnoughCredits}
        >
          {loading
            ? `Creating ${pageCount}-page coloring book...`
            : `Generate ${pageCount}-Page Coloring Book`}
        </button>
      </form>

      {pages.length > 0 && (
        <div className="mt-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold">
              {book?.title ?? 'Your Coloring Book'} ({pages.length}/{pageCount})
            </h2>
            {book && (
              <div className="flex gap-2">
                <button
                  type="button"
                  className="btn-primary text-sm"
                  onClick={() => api.downloadBookPdf(book.id, `${book.title}.pdf`)}
                >
                  Download PDF
                </button>
                <button
                  type="button"
                  className="btn-outline text-sm"
                  onClick={() => api.downloadBook(book.id, `${book.title}.zip`)}
                >
                  Download ZIP
                </button>
              </div>
            )}
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {pages.map((page) => (
              <div key={page.id} className="card overflow-hidden">
                <div className="bg-pink-50 px-3 py-1 text-xs font-semibold text-[var(--pink)]">
                  Page {page.page_number}
                </div>
                <AuthImage
                  src={page.image_url}
                  alt={page.subject}
                  className="aspect-square w-full object-cover"
                />
                <div className="p-3">
                  <p className="line-clamp-2 text-sm font-medium">{page.subject}</p>
                  {page.style && <p className="mt-1 text-xs text-gray-500">{page.style}</p>}
                  <button
                    type="button"
                    className="mt-2 text-xs font-medium text-[var(--pink)]"
                    onClick={() =>
                      downloadAuthImage(page.image_url, `page-${page.page_number}.png`)
                    }
                  >
                    Download page
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
