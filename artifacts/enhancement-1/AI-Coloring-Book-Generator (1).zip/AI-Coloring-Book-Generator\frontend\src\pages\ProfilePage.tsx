import { useUser } from '../hooks/useUser';

export function ProfilePage() {
  const { user } = useUser();

  return (
    <div className="mx-auto max-w-lg">
      <h1 className="text-2xl font-bold">My Profile</h1>
      <div className="card mt-8 space-y-4 p-6">
        <div>
          <p className="text-sm text-gray-500">Name</p>
          <p className="font-semibold">{user?.name || '—'}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Email</p>
          <p className="font-semibold">{user?.email}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Current Plan</p>
          <p className="font-semibold">{user?.active_plan ? user.active_plan.charAt(0).toUpperCase() + user.active_plan.slice(1) : 'No active plan'}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Credits</p>
          <p className="font-semibold">{user?.total_credits ?? 0} total ({user?.plan_credits ?? 0} plan · {user?.payg_credits ?? 0} PAYG)</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Member since</p>
          <p className="font-semibold">{user?.created_at ? new Date(user.created_at).toLocaleDateString() : '—'}</p>
        </div>
      </div>
    </div>
  );
}
