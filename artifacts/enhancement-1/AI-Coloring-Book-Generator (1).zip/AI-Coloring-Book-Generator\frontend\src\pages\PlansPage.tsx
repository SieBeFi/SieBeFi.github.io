import { useEffect, useState } from 'react';
import { api, type CreditLot } from '../api';
import { useUser } from '../hooks/useUser';

const PLANS = [
  { id: 'starter', name: 'Starter', credits: 150, monthly: 6.57, yearly: 59.13 },
  { id: 'hobby', name: 'Hobby', credits: 500, monthly: 13.32, yearly: 119.88 },
  { id: 'artist', name: 'Artist', credits: 1250, monthly: 28.89, yearly: 260.01 },
  { id: 'business', name: 'Business', credits: 3000, monthly: 59.99, yearly: 539.91 },
];

export function PlansPage() {
  const { user } = useUser();
  const [amount, setAmount] = useState(5);
  const [lots, setLots] = useState<CreditLot[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState('');

  useEffect(() => {
    api.creditLots().then(setLots).catch(() => setLots([]));
  }, []);

  async function subscribe(plan: string) {
    setLoading(plan);
    setError('');
    try {
      const { checkout_url } = await api.checkout({ plan });
      window.location.href = checkout_url;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Checkout failed');
      setLoading('');
    }
  }

  async function payg() {
    setLoading('payg');
    setError('');
    try {
      const { checkout_url } = await api.checkout({ amount_usd: amount });
      window.location.href = checkout_url;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Checkout failed');
      setLoading('');
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold">Plans & Credits</h1>
      <p className="text-gray-500">Dashboard / Recharge</p>

      {error && <p className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-600">{error}</p>}

      <div className="mt-8 grid gap-6 md:grid-cols-4">
        {PLANS.map((plan) => (
          <div key={plan.id} className="card p-6">
            <h3 className="text-lg font-bold">{plan.name}</h3>
            <p className="mt-2 text-3xl font-extrabold text-[var(--pink)]">${plan.monthly.toFixed(2)}<span className="text-base font-normal text-gray-400">/mo</span></p>
            <p className="text-sm text-gray-400">${plan.yearly}/yr <span className="text-green-600">(25% off)</span></p>
            <p className="mt-2 text-sm text-gray-500">{plan.credits} credits/month</p>
            <button
              className="btn-primary mt-6 w-full text-sm disabled:opacity-50"
              onClick={() => subscribe(plan.id)}
              disabled={loading === plan.id}
            >
              {loading === plan.id ? 'Redirecting...' : 'Subscribe'}
            </button>
          </div>
        ))}
      </div>

      <div className="card mt-10 p-6">
        <h2 className="text-lg font-bold">Pay As You Go</h2>
        <p className="text-sm text-gray-500">
          Add one-off credits when your subscription is expired or canceled.
        </p>
        <p className="mt-2 text-sm">Balance: <span className="font-semibold text-[var(--pink)]">{user?.payg_credits ?? 0} credits</span></p>

        <div className="mt-4 flex flex-wrap items-end gap-4">
          <div>
            <label className="mb-1 block text-sm font-medium">Amount (USD)</label>
            <input className="input w-32" type="number" min={5} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
          </div>
          <div className="flex gap-2">
            {[5, 10, 25, 50].map((v) => (
              <button key={v} type="button" className="rounded-xl border border-gray-200 px-4 py-2 text-sm hover:bg-pink-50" onClick={() => setAmount(v)}>
                ${v}
              </button>
            ))}
          </div>
          <button className="btn-primary disabled:opacity-50" onClick={payg} disabled={loading === 'payg'}>
            {loading === 'payg' ? 'Redirecting...' : 'Pay with Stripe'}
          </button>
        </div>
      </div>

      <div className="card mt-8 overflow-hidden">
        <div className="border-b border-gray-100 px-6 py-4 font-semibold">Credit Lots</div>
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-500">
            <tr>
              <th className="px-6 py-3">Source</th>
              <th className="px-6 py-3">Granted</th>
              <th className="px-6 py-3">Expires</th>
              <th className="px-6 py-3">Remaining / Total</th>
            </tr>
          </thead>
          <tbody>
            {lots.map((lot) => (
              <tr key={lot.id} className="border-t border-gray-50">
                <td className="px-6 py-3 capitalize">{lot.plan_name || lot.source}</td>
                <td className="px-6 py-3">{new Date(lot.granted_at).toLocaleString()}</td>
                <td className="px-6 py-3">{lot.expires_at ? new Date(lot.expires_at).toLocaleDateString() : 'Never'}</td>
                <td className="px-6 py-3 font-semibold">{lot.remaining_credits} / {lot.total_credits}</td>
              </tr>
            ))}
            {!lots.length && (
              <tr><td colSpan={4} className="px-6 py-8 text-center text-gray-400">No credit lots</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
