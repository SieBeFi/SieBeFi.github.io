@echo off
cd /d "%~dp0"

if not exist .env (
    echo Creating .env file...
    copy .env.example .env >nul
)

echo.
echo ============================================
echo  ColoringBooks.AI - API Key Setup
echo ============================================
echo.
echo Opening .env in Notepad...
echo.
echo Add these values:
echo   GEMINI_API_KEY = your key from aistudio.google.com/apikey
echo   OPENAI_API_KEY = your key from platform.openai.com/api-keys
echo   SECRET_KEY     = any long random string
echo.
echo Stripe keys are optional (only needed for payments).
echo.
echo Save the file and close Notepad when done.
echo ============================================
echo.

notepad .env

echo.
echo Done! Now run start-api.bat and start-frontend.bat
pause
