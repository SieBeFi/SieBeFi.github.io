import { Link } from 'react-router-dom';

export function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2 text-xl font-bold">
          <span className="text-2xl">🖍️</span>
          Coloring Books
        </div>
        <nav className="hidden items-center gap-8 text-sm font-medium text-gray-600 md:flex">
          <a href="#features">Features</a>
          <a href="#gallery">Gallery</a>
          <a href="#pricing">Pricing</a>
        </nav>
        <div className="flex items-center gap-3">
          <Link to="/login" className="text-sm font-medium text-gray-600 hover:text-gray-900">
            Login
          </Link>
          <Link to="/register" className="btn-primary px-5 py-2 text-sm">
            Register
          </Link>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 py-16 md:grid-cols-2">
        <div>
          <h1 className="text-5xl leading-tight font-extrabold text-[var(--navy)]">
            Turn text & photos into{' '}
            <span className="bg-gradient-to-r from-pink-500 via-yellow-400 to-cyan-400 bg-clip-text text-transparent">
              coloring books
            </span>{' '}
            instantly
          </h1>
          <p className="mt-6 text-lg text-gray-500">
            One click. Endless creativity. Transform any idea into a beautiful coloring page with
            advanced AI.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link to="/register" className="btn-primary">
              Try 10 Pages Free Trial
            </Link>
            <button className="btn-outline flex items-center gap-2">
              <span>▶</span> Watch Video
            </button>
          </div>
          <p className="mt-4 flex items-center gap-2 text-sm text-gray-400">
            🛡️ No credit card required · Cancel anytime
          </p>
        </div>

        <div className="relative overflow-hidden rounded-3xl border border-gray-100 bg-gradient-to-br from-pink-50 to-purple-50 p-6 shadow-xl">
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl bg-white p-4 shadow">
              <div className="mb-2 text-xs font-semibold text-gray-400">ORIGINAL</div>
              <img
                src="/demo/original-dog.png"
                alt="Original golden retriever puppy photo"
                className="h-48 w-full rounded-xl object-cover"
              />
            </div>
            <div className="rounded-2xl bg-white p-4 shadow">
              <div className="mb-2 text-xs font-semibold text-[var(--pink)]">COLORING PAGE</div>
              <img
                src="/demo/coloring-dog.png"
                alt="Coloring book line art of golden retriever puppy"
                className="h-48 w-full rounded-xl border border-gray-200 bg-white object-cover"
              />
            </div>
          </div>
          <div className="absolute top-1/2 left-1/2 flex h-10 w-10 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white shadow-lg">
            ⇄
          </div>
        </div>
      </section>

      <section id="pricing" className="bg-gray-50 py-20">
        <div className="mx-auto max-w-6xl px-6 text-center">
          <h2 className="text-3xl font-bold">Simple pricing after your free trial</h2>
          <p className="mt-2 text-gray-500">Start with 10 free pages, then choose a plan</p>
          <div className="mt-10 grid gap-6 md:grid-cols-4">
            {[
              { name: 'Starter', credits: 150, price: '$6.57/mo' },
              { name: 'Hobby', credits: 500, price: '$13.32/mo' },
              { name: 'Artist', credits: 1250, price: '$28.89/mo' },
              { name: 'Business', credits: 3000, price: '$59.99/mo' },
            ].map((plan) => (
              <div key={plan.name} className="card p-6 text-left">
                <h3 className="text-lg font-bold">{plan.name}</h3>
                <p className="mt-2 text-3xl font-extrabold text-[var(--pink)]">{plan.price}</p>
                <p className="text-sm text-gray-500">{plan.credits} credits/month</p>
                <Link to="/register" className="btn-primary mt-6 block text-center text-sm">
                  Subscribe
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="py-8 text-center text-sm text-gray-400">
        Powered by Really Big Coloring Books, Inc.
      </footer>
    </div>
  );
}
