@echo off
cd /d "%~dp0"

python -c "import uvicorn" >nul 2>&1
if errorlevel 1 (
    echo Python packages not installed yet. Installing now...
    echo This only needs to happen once.
    echo.
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo ERROR: Failed to install packages.
        echo Try running: python -m pip install -r requirements.txt
        pause
        exit /b 1
    )
    echo.
)

echo Starting Coloring Books API on http://localhost:8000
echo Keep this window open.
echo.
python run_api.py
pause
