"""Image generation backends."""

from __future__ import annotations

from src.config import Settings
from src.generators.base import ColoringBookGenerator
from src.generators.gemini import GeminiGenerator
from src.generators.openai import OpenAIGenerator


def create_generator(settings: Settings | None = None) -> ColoringBookGenerator:
    settings = settings or Settings.from_env()
    if settings.provider == "gemini":
        return GeminiGenerator(settings)
    return OpenAIGenerator(settings)


__all__ = ["ColoringBookGenerator", "create_generator"]
