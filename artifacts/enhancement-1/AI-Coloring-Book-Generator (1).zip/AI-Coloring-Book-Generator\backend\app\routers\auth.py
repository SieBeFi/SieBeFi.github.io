"""Auth routes."""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app.auth import create_access_token, get_current_user, hash_password, verify_password
from backend.app.config import settings
from backend.app.credits import get_credit_lots, grant_credits, summarize_credits
from backend.app.database import get_db
from backend.app.models import User
from backend.app.schemas import LoginRequest, RegisterRequest, TokenResponse, UserResponse

router = APIRouter(prefix="/auth", tags=["auth"])


def _user_response(db: Session, user: User) -> UserResponse:
    lots = get_credit_lots(db, user.id)
    total, plan_credits, payg_credits = summarize_credits(lots)
    return UserResponse(
        id=user.id,
        email=user.email,
        name=user.name,
        active_plan=user.active_plan,
        total_credits=total,
        plan_credits=plan_credits,
        payg_credits=payg_credits,
        created_at=user.created_at,
    )


@router.post("/register", response_model=TokenResponse)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.scalar(select(User).where(User.email == payload.email))
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")

    user = User(
        email=payload.email,
        name=payload.name,
        password_hash=hash_password(payload.password),
    )
    db.add(user)
    db.flush()

    grant_credits(
        db,
        user,
        settings.welcome_credits,
        source="payg",
        note=f"Welcome bonus: {settings.welcome_credits} PAYG credits on registration.",
    )
    db.commit()

    return TokenResponse(access_token=create_access_token(user.id))


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    return TokenResponse(access_token=create_access_token(user.id))


@router.get("/me", response_model=UserResponse)
def me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return _user_response(db, user)
