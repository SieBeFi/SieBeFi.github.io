"""Billing and Stripe routes."""

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from backend.app.auth import get_current_user
from backend.app.config import settings
from backend.app.database import get_db
from backend.app.models import User
from backend.app.schemas import CheckoutRequest
from backend.app.stripe_service import create_payg_checkout, create_subscription_checkout, handle_checkout_completed

import stripe

router = APIRouter(prefix="/billing", tags=["billing"])


@router.post("/checkout")
def checkout(
    payload: CheckoutRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not settings.stripe_secret_key:
        raise HTTPException(
            status_code=503,
            detail="Stripe is not configured. Set STRIPE_SECRET_KEY in .env.",
        )

    try:
        if payload.plan:
            url = create_subscription_checkout(db, user, payload.plan)
        elif payload.amount_usd:
            url = create_payg_checkout(db, user, payload.amount_usd)
        else:
            raise HTTPException(status_code=400, detail="Provide plan or amount_usd")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {"checkout_url": url}


@router.post("/webhook")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    if settings.stripe_webhook_secret:
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, settings.stripe_webhook_secret
            )
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    else:
        import json
        event = json.loads(payload)

    if event.get("type") == "checkout.session.completed":
        handle_checkout_completed(db, event["data"]["object"])

    return {"received": True}
