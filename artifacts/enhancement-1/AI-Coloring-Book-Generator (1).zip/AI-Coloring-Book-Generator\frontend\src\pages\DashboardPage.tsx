import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, type DashboardStats } from '../api';
import { useUser } from '../hooks/useUser';

export function DashboardPage() {
  const { user } = useUser();
  const [stats, setStats] = useState<DashboardStats | null>(null);

  useEffect(() => {
    api.dashboard().then(setStats).catch(() => setStats(null));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="text-gray-500">Welcome back{user?.name ? `, ${user.name}` : ''}!</p>

      <div className="mt-8 grid gap-4 md:grid-cols-4">
        <ActionCard title="Create Coloring Book" color="from-red-500 to-pink-500" icon="📖" to="/app/generate" action="Generate" />
        <ActionCard title="Library" color="from-yellow-400 to-orange-400" icon="📚" to="/app/library" action="Browse" />
        <ActionCard title="Recharge" color="from-green-400 to-emerald-500" icon="💳" to="/app/plans" action="Top-Up" />
        <ActionCard title="Transactions" color="from-cyan-400 to-blue-500" icon="📋" to="/app/transactions" action="Track" />
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-4">
        <StatCard label="Available Credits" value={String(stats?.total_credits ?? user?.total_credits ?? 0)} />
        <StatCard label="Current Plan" value={stats?.active_plan ? stats.active_plan.charAt(0).toUpperCase() + stats.active_plan.slice(1) : 'No active plan'} />
        <StatCard label="Images Generated" value={String(stats?.images_generated ?? 0)} />
        <StatCard label="PAYG Credits" value={String(stats?.payg_credits ?? user?.payg_credits ?? 0)} />
      </div>

      <div className="card mt-8 overflow-hidden">
        <div className="border-b border-gray-100 px-6 py-4 font-semibold">Recent Credit Transactions</div>
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-500">
            <tr>
              <th className="px-6 py-3">Type</th>
              <th className="px-6 py-3">Amount</th>
              <th className="px-6 py-3">Note</th>
              <th className="px-6 py-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {(stats?.recent_transactions ?? []).map((tx) => (
              <tr key={tx.id} className="border-t border-gray-50">
                <td className="px-6 py-3 capitalize">{tx.action}</td>
                <td className={`px-6 py-3 font-semibold ${tx.amount >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                  {tx.amount >= 0 ? '+' : ''}{tx.amount}
                </td>
                <td className="px-6 py-3 text-gray-500">{tx.note}</td>
                <td className="px-6 py-3 text-gray-400">{new Date(tx.created_at).toLocaleString()}</td>
              </tr>
            ))}
            {!stats?.recent_transactions?.length && (
              <tr><td colSpan={4} className="px-6 py-8 text-center text-gray-400">No transactions yet</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ActionCard({ title, color, icon, to, action }: { title: string; color: string; icon: string; to: string; action: string }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br ${color} p-6 text-white shadow-lg`}>
      <div className="text-3xl">{icon}</div>
      <h3 className="mt-4 text-lg font-bold">{title}</h3>
      <Link to={to} className="mt-4 inline-block rounded-full bg-white/20 px-4 py-2 text-sm font-semibold backdrop-blur hover:bg-white/30">
        {action}
      </Link>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="card p-6">
      <p className="text-sm text-gray-500">{label}</p>
      <p className="mt-2 text-2xl font-bold">{value}</p>
    </div>
  );
}
