"""Load API keys and settings from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_PROJECT_ROOT / ".env")

SUPPORTED_PROVIDERS = ("openai", "gemini")


@dataclass(frozen=True)
class Settings:
    provider: str
    output_dir: Path
    openai_api_key: str | None = None
    openai_image_model: str = "dall-e-3"
    gemini_api_key: str | None = None
    gemini_image_model: str = "gemini-2.5-flash-image"

    @classmethod
    def from_env(cls, provider: str | None = None) -> Settings:
        selected = (provider or os.getenv("IMAGE_PROVIDER", "openai")).strip().lower()
        if selected not in SUPPORTED_PROVIDERS:
            raise ValueError(
                f"Unknown provider '{selected}'. Use one of: {', '.join(SUPPORTED_PROVIDERS)}"
            )

        output = Path(os.getenv("OUTPUT_DIR", str(_PROJECT_ROOT / "output")))
        openai_key = os.getenv("OPENAI_API_KEY", "").strip() or None
        gemini_key = (
            os.getenv("GEMINI_API_KEY", "").strip()
            or os.getenv("GOOGLE_API_KEY", "").strip()
            or None
        )

        if selected == "openai" and not openai_key:
            raise ValueError(
                "OPENAI_API_KEY is not set. Copy .env.example to .env and add your key."
            )
        if selected == "gemini" and not gemini_key:
            raise ValueError(
                "GEMINI_API_KEY (or GOOGLE_API_KEY) is not set. "
                "Get a key at https://aistudio.google.com/apikey"
            )

        return cls(
            provider=selected,
            output_dir=output,
            openai_api_key=openai_key,
            openai_image_model=os.getenv("OPENAI_IMAGE_MODEL", "dall-e-3").strip(),
            gemini_api_key=gemini_key,
            gemini_image_model=os.getenv(
                "GEMINI_IMAGE_MODEL", "gemini-2.5-flash-image"
            ).strip(),
        )

    def masked_key(self) -> str:
        key = self.openai_api_key if self.provider == "openai" else self.gemini_api_key
        if not key:
            return "(not set)"
        if len(key) <= 11:
            return "***"
        return key[:7] + "..." + key[-4:]

    def active_model(self) -> str:
        if self.provider == "gemini":
            return self.gemini_image_model
        return self.openai_image_model
