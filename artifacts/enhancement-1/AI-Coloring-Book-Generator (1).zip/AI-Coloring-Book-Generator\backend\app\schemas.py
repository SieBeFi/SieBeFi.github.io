"""Pydantic schemas."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    name: str = ""


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    active_plan: str | None
    total_credits: int
    plan_credits: int
    payg_credits: int
    created_at: datetime

    model_config = {"from_attributes": True}


class CreditLotResponse(BaseModel):
    id: int
    source: str
    plan_name: str | None
    total_credits: int
    remaining_credits: int
    granted_at: datetime
    expires_at: datetime | None

    model_config = {"from_attributes": True}


class TransactionResponse(BaseModel):
    id: int
    action: str
    amount: int
    note: str
    created_at: datetime

    model_config = {"from_attributes": True}


class GenerateRequest(BaseModel):
    subject: str = Field(min_length=2, max_length=500)
    style: str | None = None
    provider: str | None = None


class BookGenerateRequest(BaseModel):
    theme: str = Field(min_length=2, max_length=200)
    page_count: int = Field(default=10, ge=1, le=20)
    style: str | None = None
    provider: str | None = None
    title: str | None = None


class GeneratedImageResponse(BaseModel):
    id: int
    subject: str
    style: str | None
    provider: str
    image_url: str
    page_number: int | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class ColoringBookResponse(BaseModel):
    id: int
    title: str
    theme: str
    style: str | None
    provider: str
    page_count: int
    pages: list[GeneratedImageResponse]
    created_at: datetime

    model_config = {"from_attributes": True}


class BookListItem(BaseModel):
    id: int
    title: str
    theme: str
    page_count: int
    created_at: datetime

    model_config = {"from_attributes": True}


class ProvidersResponse(BaseModel):
    providers: list[str]
    default: str


class DashboardStats(BaseModel):
    total_credits: int
    plan_credits: int
    payg_credits: int
    active_plan: str | None
    images_generated: int
    recent_transactions: list[TransactionResponse]


class CheckoutRequest(BaseModel):
    plan: str | None = None
    amount_usd: int | None = None
