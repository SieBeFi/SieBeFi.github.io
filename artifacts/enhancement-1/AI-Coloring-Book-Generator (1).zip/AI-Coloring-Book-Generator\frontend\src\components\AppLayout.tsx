import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { clearToken, getToken } from '../api';
import { useUser } from '../hooks/useUser';

const navLinkClass = ({ isActive }: { isActive: boolean }) =>
  `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition ${
    isActive ? 'bg-[var(--pink)] text-white' : 'text-gray-600 hover:bg-pink-50'
  }`;

export function AppLayout() {
  const { user, refresh } = useUser();
  const navigate = useNavigate();

  function logout() {
    clearToken();
    refresh();
    navigate('/');
  }

  if (!getToken()) {
    navigate('/login');
    return null;
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <aside className="flex w-64 flex-col border-r border-gray-100 bg-white p-4">
        <Link to="/app" className="mb-8 flex items-center gap-2 px-2 text-lg font-bold">
          <span className="text-2xl">🖍️</span>
          <span>
            Coloring Books
          </span>
        </Link>

        <nav className="space-y-1">
          <NavLink to="/app" end className={navLinkClass}>
            <span>📊</span> Dashboard
          </NavLink>
        </nav>

        <p className="mt-6 mb-2 px-4 text-xs font-semibold tracking-wider text-gray-400">USER</p>
        <nav className="space-y-1">
          <NavLink to="/app/profile" className={navLinkClass}>
            <span>👤</span> My Profile
          </NavLink>
          <NavLink to="/app/plans" className={navLinkClass}>
            <span>💳</span> Plans & Credits
          </NavLink>
          <NavLink to="/app/transactions" className={navLinkClass}>
            <span>📋</span> Transactions
          </NavLink>
        </nav>

        <p className="mt-6 mb-2 px-4 text-xs font-semibold tracking-wider text-gray-400">
          ARTIFICIAL INTELLIGENCE
        </p>
        <nav className="space-y-1">
          <NavLink to="/app/generate" className={navLinkClass}>
            <span>📖</span> Create Coloring Book
          </NavLink>
          <NavLink to="/app/library" className={navLinkClass}>
            <span>📚</span> Library
          </NavLink>
        </nav>

        <div className="mt-auto rounded-xl bg-pink-50 p-4 text-sm">
          <p className="font-semibold text-[var(--pink)]">{user?.total_credits ?? 0} credits</p>
          <p className="text-gray-500">Plan {user?.plan_credits ?? 0} · PAYG {user?.payg_credits ?? 0}</p>
        </div>
      </aside>

      <div className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-gray-100 bg-white px-8 py-4">
          <div className="text-sm text-gray-500">
            {user?.email} · <span className="font-semibold text-gray-800">{user?.total_credits ?? 0} Total</span>
            <span className="text-gray-400"> (Plan {user?.plan_credits ?? 0} - PAYG {user?.payg_credits ?? 0})</span>
          </div>
          <button onClick={logout} className="text-sm font-medium text-gray-500 hover:text-gray-800">
            Logout
          </button>
        </header>
        <main className="flex-1 p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
