"""Credit balance and consumption logic."""

from __future__ import annotations

from datetime import datetime

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app.config import settings
from backend.app.models import CreditLot, Transaction, User

PLAN_CREDITS = {
    "starter": 150,
    "hobby": 500,
    "artist": 1250,
    "business": 3000,
}

PAYG_CREDITS_PER_DOLLAR = 2


def get_credit_lots(db: Session, user_id: int) -> list[CreditLot]:
    return list(
        db.scalars(
            select(CreditLot)
            .where(CreditLot.user_id == user_id)
            .order_by(CreditLot.granted_at.desc())
        )
    )


def _active_lots(lots: list[CreditLot]) -> list[CreditLot]:
    now = datetime.utcnow()
    active = []
    for lot in lots:
        if lot.remaining_credits <= 0:
            continue
        if lot.expires_at and lot.expires_at < now:
            continue
        active.append(lot)
    return active


def summarize_credits(lots: list[CreditLot]) -> tuple[int, int, int]:
    active = _active_lots(lots)
    plan_credits = sum(
        lot.remaining_credits for lot in active if lot.source == "subscription"
    )
    payg_credits = sum(
        lot.remaining_credits for lot in active if lot.source != "subscription"
    )
    return plan_credits + payg_credits, plan_credits, payg_credits


def grant_credits(
    db: Session,
    user: User,
    amount: int,
    *,
    source: str,
    plan_name: str | None = None,
    note: str,
    expires_at: datetime | None = None,
) -> CreditLot:
    lot = CreditLot(
        user_id=user.id,
        source=source,
        plan_name=plan_name,
        total_credits=amount,
        remaining_credits=amount,
        expires_at=expires_at,
    )
    db.add(lot)
    db.add(
        Transaction(
            user_id=user.id,
            action="add",
            amount=amount,
            note=note,
        )
    )
    return lot


def consume_credit(db: Session, user: User, note: str) -> None:
    consume_credits(db, user, settings.credits_per_generation, note)


def consume_credits(db: Session, user: User, amount: int, note: str) -> None:
    if amount <= 0:
        return

    lots = get_credit_lots(db, user.id)
    active = _active_lots(lots)
    total, _, _ = summarize_credits(lots)
    if total < amount:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=(
                f"Not enough credits. Need {amount}, you have {total}. "
                "Please purchase a plan or top up credits."
            ),
        )

    subscription_lots = [lot for lot in active if lot.source == "subscription"]
    payg_lots = [lot for lot in active if lot.source != "subscription"]
    ordered = subscription_lots + sorted(payg_lots, key=lambda lot: lot.granted_at)

    remaining_to_deduct = amount
    for lot in ordered:
        if remaining_to_deduct <= 0:
            break
        deduction = min(lot.remaining_credits, remaining_to_deduct)
        lot.remaining_credits -= deduction
        remaining_to_deduct -= deduction

    db.add(
        Transaction(
            user_id=user.id,
            action="use",
            amount=-amount,
            note=note,
        )
    )
