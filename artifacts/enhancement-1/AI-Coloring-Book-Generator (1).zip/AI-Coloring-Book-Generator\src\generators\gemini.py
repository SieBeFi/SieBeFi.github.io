"""Google Gemini Nano Banana coloring book generator."""

from __future__ import annotations

from pathlib import Path

from google import genai

from src.config import Settings
from src.generators.base import ColoringBookGenerator
from src.prompts import build_prompt
from src.utils import resolve_output_path


class GeminiGenerator(ColoringBookGenerator):
    """Uses Gemini's native image generation (Nano Banana) via google-genai."""

    def __init__(self, settings: Settings) -> None:
        super().__init__(settings)
        if not settings.gemini_api_key:
            raise ValueError(
                "GEMINI_API_KEY (or GOOGLE_API_KEY) is required for the gemini provider."
            )
        self.client = genai.Client(api_key=settings.gemini_api_key)

    def generate_page(
        self,
        subject: str,
        *,
        style: str | None = None,
        filename: str | None = None,
        size: str = "1024x1024",
    ) -> Path:
        del size  # Gemini Nano Banana does not use DALL-E size presets.
        prompt = build_prompt(subject, style)
        response = self.client.models.generate_content(
            model=self.settings.gemini_image_model,
            contents=prompt,
        )

        image_bytes = self._extract_image_bytes(response)
        output_path = resolve_output_path(
            self.settings.output_dir, subject, filename
        )
        output_path.write_bytes(image_bytes)
        return output_path

    @staticmethod
    def _extract_image_bytes(response: object) -> bytes:
        candidates = getattr(response, "candidates", None) or []
        for candidate in candidates:
            content = getattr(candidate, "content", None)
            if not content:
                continue
            for part in getattr(content, "parts", None) or []:
                inline_data = getattr(part, "inline_data", None)
                if inline_data and inline_data.data:
                    return inline_data.data

        raise RuntimeError("Gemini API returned no image data.")
