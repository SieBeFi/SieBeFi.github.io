"""Prompt templates optimized for coloring book line art."""

COLORING_BOOK_STYLE = (
    "black and white coloring book page, clean bold black outlines, "
    "thick line art, pure white background, no shading, no gray tones, "
    "no gradients, no color, flat 2D illustration, generous white space, "
    "suitable for children to color with crayons"
)


def build_prompt(subject: str, style: str | None = None) -> str:
    """Build a DALL-E prompt for a single coloring book page."""
    parts = [subject.strip()]
    if style:
        parts.append(style.strip())
    parts.append(COLORING_BOOK_STYLE)
    return ". ".join(parts)
