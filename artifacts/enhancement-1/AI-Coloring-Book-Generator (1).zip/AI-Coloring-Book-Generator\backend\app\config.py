"""Application settings."""

from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[2]
SUPPORTED_PROVIDERS = ("gemini", "openai")


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")

    secret_key: str = "change-me-in-production"
    database_url: str = f"sqlite:///{ROOT / 'data' / 'app.db'}"
    frontend_url: str = "http://localhost:5173"

    gemini_api_key: str = ""
    google_api_key: str = ""
    gemini_image_model: str = "gemini-2.5-flash-image"

    openai_api_key: str = ""
    openai_image_model: str = "dall-e-3"

    image_provider: str = "gemini"

    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_price_starter: str = ""
    stripe_price_hobby: str = ""
    stripe_price_artist: str = ""
    stripe_price_business: str = ""

    welcome_credits: int = 10
    credits_per_generation: int = 1

    @property
    def resolved_gemini_key(self) -> str:
        return self.gemini_api_key or self.google_api_key

    @property
    def uploads_dir(self) -> Path:
        path = ROOT / "data" / "uploads"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def available_providers(self) -> list[str]:
        providers: list[str] = []
        if self.resolved_gemini_key:
            providers.append("gemini")
        if self.openai_api_key:
            providers.append("openai")
        return providers

    def default_provider(self) -> str:
        if self.image_provider in self.available_providers():
            return self.image_provider
        available = self.available_providers()
        if not available:
            raise RuntimeError("No image API keys configured.")
        return available[0]


settings = AppSettings()
