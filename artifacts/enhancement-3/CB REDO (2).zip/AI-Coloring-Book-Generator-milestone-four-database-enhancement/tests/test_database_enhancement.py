"""Database milestone tests, independent of external image generation APIs."""
import unittest
from datetime import datetime
from sqlalchemy import create_engine, event, inspect, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from backend.app.database import Base
from backend.app.database_enhancement import add_existing_database_indexes
from backend.app.models import ColoringBook, CreditLot, GeneratedImage, User


class DatabaseEnhancementTests(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine('sqlite:///:memory:')
        @event.listens_for(self.engine, 'connect')
        def enable_foreign_keys(dbapi_conn, _):
            dbapi_conn.execute('PRAGMA foreign_keys=ON')
        Base.metadata.create_all(self.engine)
        self.db = Session(self.engine)
        self.db.add_all([User(id=1, email='a@test.local', password_hash='hash'), User(id=2, email='b@test.local', password_hash='hash')])
        self.db.commit()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def test_negative_credit_is_rejected(self):
        self.db.add(CreditLot(user_id=1, source='test', total_credits=5, remaining_credits=-1))
        with self.assertRaises(IntegrityError):
            self.db.commit()
        self.db.rollback()

    def test_remaining_credit_cannot_exceed_total(self):
        self.db.add(CreditLot(user_id=1, source='test', total_credits=5, remaining_credits=6))
        with self.assertRaises(IntegrityError):
            self.db.commit()
        self.db.rollback()

    def test_invalid_book_page_count_is_rejected(self):
        self.db.add(ColoringBook(user_id=1, title='Test', theme='Animals', page_count=0))
        with self.assertRaises(IntegrityError):
            self.db.commit()
        self.db.rollback()

    def test_duplicate_page_number_is_rejected(self):
        self.db.add(ColoringBook(id=1, user_id=1, title='Test', theme='Animals', page_count=2))
        self.db.commit()
        self.db.add(GeneratedImage(user_id=1, book_id=1, page_number=1, subject='Cat', file_path='cat.png'))
        self.db.commit()
        self.db.add(GeneratedImage(user_id=1, book_id=1, page_number=1, subject='Dog', file_path='dog.png'))
        with self.assertRaises(IntegrityError):
            self.db.commit()
        self.db.rollback()

    def test_user_scoped_lookup_excludes_other_users(self):
        self.db.add(GeneratedImage(user_id=1, subject='Cat', file_path='cat.png'))
        self.db.commit()
        result = self.db.scalar(select(GeneratedImage).where(GeneratedImage.id == 1, GeneratedImage.user_id == 2))
        self.assertIsNone(result)

    def test_indexes_present_and_idempotent(self):
        add_existing_database_indexes(self.engine)
        add_existing_database_indexes(self.engine)
        indexes = {i['name'] for i in inspect(self.engine).get_indexes('generated_images')}
        self.assertIn('ix_images_user_created', indexes)
        self.assertIn('ix_images_book_page', indexes)


if __name__ == '__main__':
    unittest.main()
