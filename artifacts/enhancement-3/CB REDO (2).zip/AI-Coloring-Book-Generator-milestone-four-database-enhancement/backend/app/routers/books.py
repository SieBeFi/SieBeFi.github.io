"""Batch coloring book generation routes."""

from __future__ import annotations

import json
import zipfile
from io import BytesIO
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app.auth import get_current_user
from backend.app.book_planner import plan_book_pages
from backend.app.config import settings
from backend.app.credits import consume_credits, get_credit_lots, summarize_credits
from backend.app.database import get_db
from backend.app.image_service import generate_coloring_page_bytes, save_user_image
from backend.app.models import ColoringBook, GeneratedImage, User
from backend.app.pdf_service import build_book_pdf
from backend.app.schemas import (
    BookGenerateRequest,
    BookListItem,
    ColoringBookResponse,
    GeneratedImageResponse,
)

router = APIRouter(prefix="/books", tags=["books"])


def _image_response(image: GeneratedImage) -> GeneratedImageResponse:
    return GeneratedImageResponse(
        id=image.id,
        subject=image.subject,
        style=image.style,
        provider=image.provider,
        image_url=f"/api/images/{image.id}",
        page_number=image.page_number,
        created_at=image.created_at,
    )


def _book_response(book: ColoringBook) -> ColoringBookResponse:
    pages = sorted(book.pages, key=lambda p: p.page_number or 0)
    return ColoringBookResponse(
        id=book.id,
        title=book.title,
        theme=book.theme,
        style=book.style,
        provider=book.provider,
        page_count=book.page_count,
        pages=[_image_response(page) for page in pages],
        created_at=book.created_at,
    )


def _validate_provider(provider: str | None) -> str:
    providers = settings.available_providers()
    if not providers:
        raise HTTPException(status_code=503, detail="No image API keys configured.")
    selected = (provider or settings.default_provider()).lower()
    if selected not in providers:
        raise HTTPException(
            status_code=400,
            detail=f"Provider '{selected}' is not available. Configured: {', '.join(providers)}",
        )
    return selected


@router.get("", response_model=list[BookListItem])
def list_books(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    books = db.scalars(
        select(ColoringBook)
        .where(ColoringBook.user_id == user.id)
        .order_by(ColoringBook.created_at.desc())
    )
    return [BookListItem.model_validate(book) for book in books]


@router.get("/{book_id}", response_model=ColoringBookResponse)
def get_book(
    book_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    book = db.scalar(
        select(ColoringBook).where(ColoringBook.id == book_id, ColoringBook.user_id == user.id)
    )
    if not book:
        raise HTTPException(status_code=404, detail="Coloring book not found")
    return _book_response(book)


def _safe_filename(title: str, extension: str) -> str:
    safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in title)
    return f"{safe or 'coloring-book'}.{extension}"


@router.get("/{book_id}/download")
def download_book(
    book_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    book = db.scalar(
        select(ColoringBook).where(ColoringBook.id == book_id, ColoringBook.user_id == user.id)
    )
    if not book:
        raise HTTPException(status_code=404, detail="Coloring book not found")

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for page in sorted(book.pages, key=lambda p: p.page_number or 0):
            path = Path(page.file_path)
            if path.exists():
                archive.write(path, f"page-{page.page_number:02d}.png")

    buffer.seek(0)
    filename = _safe_filename(book.title, "zip")
    return StreamingResponse(
        buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{book_id}/download/pdf")
def download_book_pdf(
    book_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    book = db.scalar(
        select(ColoringBook).where(ColoringBook.id == book_id, ColoringBook.user_id == user.id)
    )
    if not book:
        raise HTTPException(status_code=404, detail="Coloring book not found")

    paths = [
        Path(page.file_path)
        for page in sorted(book.pages, key=lambda p: p.page_number or 0)
    ]
    try:
        buffer = build_book_pdf(paths)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    filename = _safe_filename(book.title, "pdf")
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/generate")
def generate_book(
    payload: BookGenerateRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    selected = _validate_provider(payload.provider)
    lots = get_credit_lots(db, user.id)
    total, _, _ = summarize_credits(lots)
    if total < payload.page_count:
        raise HTTPException(
            status_code=402,
            detail=f"Not enough credits. Need {payload.page_count}, you have {total}.",
        )

    page_plans = plan_book_pages(
        payload.theme,
        payload.page_count,
        style=payload.style,
        seed=user.id,
    )
    title = payload.title or f"{payload.theme.title()} Coloring Book"

    def event_stream():
        book: ColoringBook | None = None
        generated_images: list[GeneratedImage] = []

        try:
            consume_credits(
                db,
                user,
                payload.page_count,
                note=f"Coloring book ({payload.page_count} pages): {payload.theme[:50]}",
            )

            book = ColoringBook(
                user_id=user.id,
                title=title,
                theme=payload.theme,
                style=payload.style,
                provider=selected,
                page_count=payload.page_count,
            )
            db.add(book)
            db.flush()

            yield f"data: {json.dumps({'type': 'start', 'total': payload.page_count, 'title': title})}\n\n"

            for index, plan in enumerate(page_plans, start=1):
                yield f"data: {json.dumps({'type': 'progress', 'current': index, 'total': payload.page_count, 'subject': plan['subject']})}\n\n"

                image_bytes, provider_used = generate_coloring_page_bytes(
                    plan["subject"],
                    plan["style"],
                    provider=selected,
                )
                file_path = save_user_image(user.id, image_bytes)
                record = GeneratedImage(
                    user_id=user.id,
                    book_id=book.id,
                    page_number=index,
                    subject=plan["subject"],
                    style=plan["style"],
                    provider=provider_used,
                    file_path=str(file_path),
                )
                db.add(record)
                db.flush()
                generated_images.append(record)

                yield f"data: {json.dumps({'type': 'page', 'page': _image_response(record).model_dump(mode='json')})}\n\n"

            db.commit()
            db.refresh(book)
            book.pages = list(
                db.scalars(
                    select(GeneratedImage)
                    .where(GeneratedImage.book_id == book.id)
                    .order_by(GeneratedImage.page_number)
                )
            )
            yield f"data: {json.dumps({'type': 'complete', 'book': _book_response(book).model_dump(mode='json')})}\n\n"

        except Exception as exc:
            db.rollback()
            yield f"data: {json.dumps({'type': 'error', 'message': str(exc)})}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")
