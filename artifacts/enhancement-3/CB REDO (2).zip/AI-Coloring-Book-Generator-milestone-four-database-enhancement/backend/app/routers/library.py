"""Library and dashboard routes."""

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from backend.app.auth import get_current_user
from backend.app.credits import get_credit_lots, summarize_credits
from backend.app.database import get_db
from backend.app.models import GeneratedImage, Transaction, User
from backend.app.schemas import (
    CreditLotResponse,
    DashboardStats,
    GeneratedImageResponse,
    TransactionResponse,
)

router = APIRouter(tags=["library"])


@router.get("/library", response_model=list[GeneratedImageResponse])
def list_library(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    images = db.scalars(
        select(GeneratedImage)
        .where(GeneratedImage.user_id == user.id)
        .order_by(GeneratedImage.created_at.desc())
    )
    return [
        GeneratedImageResponse(
            id=img.id,
            subject=img.subject,
            style=img.style,
            provider=getattr(img, "provider", None) or "gemini",
            image_url=f"/api/images/{img.id}",
            page_number=getattr(img, "page_number", None),
            created_at=img.created_at,
        )
        for img in images
    ]


@router.get("/images/{image_id}")
def get_image(
    image_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    image = db.scalar(
        select(GeneratedImage).where(GeneratedImage.id == image_id, GeneratedImage.user_id == user.id)
    )
    if not image:
        raise HTTPException(status_code=404, detail="Image not found")
    return FileResponse(image.file_path, media_type="image/png")


@router.get("/dashboard", response_model=DashboardStats)
def dashboard(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    lots = get_credit_lots(db, user.id)
    total, plan_credits, payg_credits = summarize_credits(lots)
    image_count = db.scalar(
        select(func.count()).select_from(GeneratedImage).where(GeneratedImage.user_id == user.id)
    ) or 0
    recent = db.scalars(
        select(Transaction)
        .where(Transaction.user_id == user.id)
        .order_by(Transaction.created_at.desc())
        .limit(8)
    )
    return DashboardStats(
        total_credits=total,
        plan_credits=plan_credits,
        payg_credits=payg_credits,
        active_plan=user.active_plan,
        images_generated=image_count,
        recent_transactions=[TransactionResponse.model_validate(tx) for tx in recent],
    )


@router.get("/credits/lots", response_model=list[CreditLotResponse])
def credit_lots(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return [CreditLotResponse.model_validate(lot) for lot in get_credit_lots(db, user.id)]


@router.get("/transactions", response_model=list[TransactionResponse])
def transactions(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Transaction)
        .where(Transaction.user_id == user.id)
        .order_by(Transaction.created_at.desc())
    )
    return [TransactionResponse.model_validate(tx) for tx in rows]
