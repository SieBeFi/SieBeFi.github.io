"""SQLAlchemy models."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.app.database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120), default="")
    password_hash: Mapped[str] = mapped_column(String(255))
    stripe_customer_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    active_plan: Mapped[str | None] = mapped_column(String(50), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    credit_lots: Mapped[list["CreditLot"]] = relationship(back_populates="user")
    transactions: Mapped[list["Transaction"]] = relationship(back_populates="user")
    images: Mapped[list["GeneratedImage"]] = relationship(back_populates="user")
    books: Mapped[list["ColoringBook"]] = relationship(back_populates="user")


class ColoringBook(Base):
    __tablename__ = "coloring_books"
    __table_args__ = (
        CheckConstraint("page_count > 0", name="ck_books_positive_pages"),
        Index("ix_books_user_created", "user_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    title: Mapped[str] = mapped_column(String(200))
    theme: Mapped[str] = mapped_column(String(500))
    style: Mapped[str | None] = mapped_column(String(200), nullable=True)
    provider: Mapped[str] = mapped_column(String(20), default="gemini")
    page_count: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped[User] = relationship(back_populates="books")
    pages: Mapped[list["GeneratedImage"]] = relationship(back_populates="book")


class CreditLot(Base):
    __tablename__ = "credit_lots"
    __table_args__ = (
        CheckConstraint("total_credits >= 0", name="ck_lots_total_nonnegative"),
        CheckConstraint("remaining_credits >= 0", name="ck_lots_remaining_nonnegative"),
        CheckConstraint("remaining_credits <= total_credits", name="ck_lots_remaining_within_total"),
        Index("ix_lots_user_expiry", "user_id", "expires_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    source: Mapped[str] = mapped_column(String(50))
    plan_name: Mapped[str | None] = mapped_column(String(50), nullable=True)
    total_credits: Mapped[int] = mapped_column(Integer)
    remaining_credits: Mapped[int] = mapped_column(Integer)
    granted_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    user: Mapped[User] = relationship(back_populates="credit_lots")


class Transaction(Base):
    __tablename__ = "transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(50))
    amount: Mapped[int] = mapped_column(Integer)
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped[User] = relationship(back_populates="transactions")


class GeneratedImage(Base):
    __tablename__ = "generated_images"
    __table_args__ = (
        CheckConstraint("page_number IS NULL OR page_number > 0", name="ck_images_positive_page"),
        UniqueConstraint("book_id", "page_number", name="uq_book_page"),
        Index("ix_images_user_created", "user_id", "created_at"),
        Index("ix_images_book_page", "book_id", "page_number"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    book_id: Mapped[int | None] = mapped_column(ForeignKey("coloring_books.id"), nullable=True)
    page_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
    subject: Mapped[str] = mapped_column(String(500))
    style: Mapped[str | None] = mapped_column(String(200), nullable=True)
    provider: Mapped[str] = mapped_column(String(20), default="gemini")
    file_path: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped[User] = relationship(back_populates="images")
    book: Mapped[ColoringBook | None] = relationship(back_populates="pages")
