"""FastAPI application entry point."""

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import inspect, text

from backend.app.config import settings
from backend.app.database import Base, engine
from backend.app.routers import auth, billing, books, generate, library

Path("data").mkdir(exist_ok=True)
Base.metadata.create_all(bind=engine)

inspector = inspect(engine)
table_names = inspector.get_table_names()

if "generated_images" in table_names:
    columns = {col["name"] for col in inspector.get_columns("generated_images")}
    with engine.begin() as conn:
        if "provider" not in columns:
            conn.execute(
                text(
                    "ALTER TABLE generated_images "
                    "ADD COLUMN provider VARCHAR(20) DEFAULT 'gemini'"
                )
            )
        if "book_id" not in columns:
            conn.execute(text("ALTER TABLE generated_images ADD COLUMN book_id INTEGER"))
        if "page_number" not in columns:
            conn.execute(text("ALTER TABLE generated_images ADD COLUMN page_number INTEGER"))

from backend.app.database_enhancement import add_existing_database_indexes

add_existing_database_indexes(engine)

app = FastAPI(title="ColoringBooks.AI API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url, "http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(generate.router, prefix="/api")
app.include_router(books.router, prefix="/api")
app.include_router(library.router, prefix="/api")
app.include_router(billing.router, prefix="/api")


@app.get("/api/health")
def health():
    return {"status": "ok"}
