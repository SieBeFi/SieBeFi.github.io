"""Idempotent indexes for existing databases; constraints require a reviewed migration."""
from sqlalchemy import inspect, text

INDEXES = {
    'coloring_books': ('ix_books_user_created', 'user_id, created_at'),
    'generated_images': ('ix_images_user_created', 'user_id, created_at'),
    'generated_images_page': ('ix_images_book_page', 'book_id, page_number'),
    'credit_lots': ('ix_lots_user_expiry', 'user_id, expires_at'),
}


def add_existing_database_indexes(engine):
    """Add non-unique performance indexes without rewriting existing user data."""
    inspector = inspect(engine)
    tables = set(inspector.get_table_names())
    with engine.begin() as connection:
        for table_key, (index_name, columns) in INDEXES.items():
            table = 'generated_images' if table_key == 'generated_images_page' else table_key
            if table not in tables:
                continue
            present = {col['name'] for col in inspector.get_columns(table)}
            if not set(columns.split(', ')).issubset(present):
                continue
            connection.execute(text(f'CREATE INDEX IF NOT EXISTS {index_name} ON {table} ({columns})') if engine.dialect.name == 'sqlite' else text(f'CREATE INDEX {index_name} ON {table} ({columns})') ) if index_name not in {idx['name'] for idx in inspector.get_indexes(table)} else None
