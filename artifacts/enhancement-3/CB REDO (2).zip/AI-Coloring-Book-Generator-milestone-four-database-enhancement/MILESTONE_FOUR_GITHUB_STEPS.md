# Upload to GitHub

1. Open your AI-Coloring-Book-Generator repository on GitHub.
2. Create a new branch from the existing main branch named `milestone-four-database-enhancement`.
3. Upload the **contents** of this ZIP into that branch, preserving directory structure (do not put everything inside an extra enclosing folder). GitHub's browser upload may not conveniently handle folders; GitHub Desktop or command line is recommended.
4. With GitHub Desktop: clone the repository, switch to the new branch, copy the updated files from this ZIP over the cloned files, review changes, commit `CS 499 Milestone Four: database constraints, indexes, scoped queries and tests`, and push.
5. Compare the new branch with `main` in a GitHub pull request. Include the narrative and the successful test output in your submission.
6. Do not merge until you have verified the comparison and tested with your intended database.

## Local test command
`python -m unittest discover -s tests -p 'test_database_enhancement.py' -v`

**Important:** Constraints apply to newly created database tables. Do not deploy against an existing database expecting those constraints to be installed automatically. Back up and plan a migration first.
