"""Base interface for coloring book generators."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.config import Settings


class ColoringBookGenerator(ABC):
    def __init__(self, settings: "Settings | None") -> None:
        self.settings = settings

    @abstractmethod
    def generate_page(
        self,
        subject: str,
        *,
        style: str | None = None,
        filename: str | None = None,
        size: str = "1024x1024",
    ) -> Path:
        """Generate one coloring book page and save it as a PNG."""

    def generate_book(
        self,
        subjects: list[str],
        *,
        style: str | None = None,
        size: str = "1024x1024",
    ) -> tuple[list[Path], list[dict[str, str]]]:
        """Generate multiple coloring book pages from a list of subjects."""
        from src.utils import slugify

        successful_pages: list[Path] = []
        failed_pages: list[dict[str, str]] = []

        for index, subject in enumerate(subjects, start=1):
            filename = f"{index:02d}-{slugify(subject)}.png"

            try:
                path = self.generate_page(
                    subject,
                    style=style,
                    filename=filename,
                    size=size,
                )
                successful_pages.append(path)

            except Exception as error:
                failed_pages.append(
                    {
                        "subject": subject,
                        "error": str(error),
                    }
                )

        return successful_pages, failed_pages
