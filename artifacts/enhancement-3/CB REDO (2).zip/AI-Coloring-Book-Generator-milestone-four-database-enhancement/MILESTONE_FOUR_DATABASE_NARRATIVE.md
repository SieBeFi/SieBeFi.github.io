# CS 499 Milestone Four: Database Enhancement Narrative

**Artifact:** AI Coloring Book Generator  
**Category:** Databases

## Why I selected this artifact
I selected my AI Coloring Book Generator because it is more than an image generator. The application has user accounts, saved coloring books, individual image pages, and credits. These features depend on database records being accurate and available only to the correct user. Improving this database is important because people need to trust that their generated work and purchased credits are handled correctly.

## Original artifact and identified weaknesses
The original version already used SQLAlchemy models, but it did not define database-level checks for invalid credit balances or page counts. It also did not prevent duplicate page numbers within one book. Some frequently used queries filtered by user and sorted by creation time without matching composite indexes. The book and image detail endpoints loaded records by primary key before checking ownership.

## Enhancements completed
I added SQL CHECK constraints to reject negative credits, credit balances greater than the amount granted, zero or negative book page counts, and negative or zero page numbers. A unique constraint prevents two pages of the same coloring book from sharing the same page number. I added composite indexes for a user's books and images ordered by creation date, for pages within a book, and for credit lots by user and expiration date. These indexes support common library and credit queries, although real performance improvements should be measured with representative production-sized data.

I also changed the book and image detail queries so that the database query includes the authenticated user's ID. This is defense in depth: the application still uses authentication, and the query now retrieves only a record belonging to that user. Requests for other users' records still receive a not-found response.

## Testing and evidence
I added six automated SQLite tests. They verify that negative credits, excess remaining credits, invalid book page counts, and duplicate page numbers are rejected; that a user-scoped lookup does not return another user's image; and that indexes are present and can be initialized repeatedly. I ran `python -m unittest discover -s tests -p 'test_database_enhancement.py' -v` and all six tests passed in the local test environment.

## Database deployment considerations
The new constraints are applied when creating a fresh database. Existing databases need a reviewed migration that checks and cleans historical data before rebuilding affected SQLite tables or applying appropriate ALTER statements on another database engine. The application adds non-unique performance indexes to existing SQLite databases, but it does **not** silently rebuild existing tables or claim to enforce the new constraints retroactively. Back up real data before migrating. This distinction matters because a successful new-install test does not prove that an old database has been migrated.

## Skills and course outcomes
This enhancement demonstrates my ability to assess an existing application, design relational database protections, implement safer data access, and verify changes with repeatable tests. I practiced using SQLAlchemy constraints and indexes, reasoning about ownership and integrity, and documenting deployment limitations. I also improved the quality of the artifact by making database behavior testable instead of relying only on application-side assumptions. These skills relate to designing and evaluating computing solutions, communicating technical decisions, and using security-minded development practices.

## Before and after evidence
Compare `backend/app/models.py`, `backend/app/routers/books.py`, and `backend/app/routers/library.py` in the original version against this version. New files include `backend/app/database_enhancement.py`, `tests/test_database_enhancement.py`, and this narrative. The previous algorithms milestone remains unchanged.
